import "dotenv/config";

import {
    Client,
    GatewayIntentBits,
    Partials,
    EmbedBuilder
} from "discord.js";

import { GoogleGenAI } from "@google/genai";

import fs from "node:fs";
import path from "node:path";

import { config } from "./config.js";


// ============================================================
// ENVIRONMENT
// ============================================================

const TOKEN = process.env.DISCORD_TOKEN;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

const VERIFY_CHANNEL_ID = process.env.VERIFY_CHANNEL_ID;
const VERIFY_ROLE_ID = process.env.VERIFY_ROLE_ID;
const LOG_CHANNEL_ID = process.env.LOG_CHANNEL_ID;

const YOUTUBE_CHANNEL_NAME =
    process.env.YOUTUBE_CHANNEL_NAME;

const YOUTUBE_HANDLE =
    process.env.YOUTUBE_HANDLE;


// ============================================================
// ENVIRONMENT CHECK
// ============================================================

if (!TOKEN) {
    console.error("❌ DISCORD_TOKEN is missing.");
    process.exit(1);
}

if (!GEMINI_API_KEY) {
    console.error("❌ GEMINI_API_KEY is missing.");
    process.exit(1);
}

if (!VERIFY_CHANNEL_ID) {
    console.error("❌ VERIFY_CHANNEL_ID is missing.");
    process.exit(1);
}

if (!VERIFY_ROLE_ID) {
    console.error("❌ VERIFY_ROLE_ID is missing.");
    process.exit(1);
}

if (!YOUTUBE_CHANNEL_NAME) {
    console.error("❌ YOUTUBE_CHANNEL_NAME is missing.");
    process.exit(1);
}

if (!YOUTUBE_HANDLE) {
    console.error("❌ YOUTUBE_HANDLE is missing.");
    process.exit(1);
}


// ============================================================
// DATABASE
// ============================================================

const DATA_DIR =
    path.join(process.cwd(), "data");

const DATA_FILE =
    path.join(DATA_DIR, "verifications.json");


if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, {
        recursive: true
    });
}


if (!fs.existsSync(DATA_FILE)) {

    fs.writeFileSync(
        DATA_FILE,
        JSON.stringify(
            {
                verified: {},
                attempts: {}
            },
            null,
            2
        )
    );

}


function loadDatabase() {

    try {

        return JSON.parse(
            fs.readFileSync(
                DATA_FILE,
                "utf8"
            )
        );

    } catch {

        return {
            verified: {},
            attempts: {}
        };

    }

}


function saveDatabase(db) {

    fs.writeFileSync(
        DATA_FILE,
        JSON.stringify(
            db,
            null,
            2
        )
    );

}


// ============================================================
// DISCORD CLIENT
// ============================================================

const client = new Client({

    intents: [

        GatewayIntentBits.Guilds,

        GatewayIntentBits.GuildMessages,

        GatewayIntentBits.MessageContent

    ],

    partials: [

        Partials.Channel,

        Partials.Message

    ]

});


// ============================================================
// GEMINI
// ============================================================

const ai = new GoogleGenAI({
    apiKey: GEMINI_API_KEY
});


// ============================================================
// HELPERS
// ============================================================

function sleep(ms) {

    return new Promise(
        resolve => setTimeout(resolve, ms)
    );

}


function isImage(attachment) {

    if (!attachment.contentType) {
        return false;
    }

    return config.allowedMimeTypes.includes(
        attachment.contentType
    );

}


function getMimeType(attachment) {

    if (
        attachment.contentType ===
        "image/jpg"
    ) {

        return "image/jpeg";

    }

    return attachment.contentType;

}


async function downloadImage(url) {

    const response =
        await fetch(url);


    if (!response.ok) {

        throw new Error(
            `Failed to download image: HTTP ${response.status}`
        );

    }


    const buffer =
        Buffer.from(
            await response.arrayBuffer()
        );


    if (
        buffer.length >
        config.maxImageSize
    ) {

        throw new Error(
            "Image is too large."
        );

    }


    return buffer;

}


// ============================================================
// GEMINI VERIFICATION
// ============================================================

async function verifyScreenshot(
    imageBuffer,
    mimeType
) {

    const base64Image =
        imageBuffer.toString("base64");


    const prompt = `

You are a strict YouTube subscription screenshot verification system.

The Discord server owner wants to verify that a user has subscribed
to this specific YouTube channel.

Channel name:
${YOUTUBE_CHANNEL_NAME}

YouTube handle:
${YOUTUBE_HANDLE}


Analyze the attached screenshot carefully.


APPROVE ONLY IF:

1. The screenshot clearly shows YouTube.

2. The correct channel is visible.

3. The channel matches:

${YOUTUBE_CHANNEL_NAME}

or:

${YOUTUBE_HANDLE}

4. The YouTube subscription state clearly shows:

"Subscribed"

or an equivalent subscribed state.


IMPORTANT:

A "Subscribe" button means the user is NOT subscribed.

Do NOT approve screenshots merely because:

- YouTube is visible
- The channel name is visible
- The user is watching a video
- A Subscribe button exists
- The screenshot is too blurry
- The subscription state cannot be determined


Reject:

- unrelated screenshots
- edited/fake-looking screenshots
- screenshots where the relevant UI is unreadable
- screenshots showing "Subscribe"
- screenshots without clear channel identity
- screenshots where subscription status cannot be confirmed


Return ONLY JSON.

Use exactly:

{
  "valid": true,
  "confidence": 95,
  "reason": "The screenshot clearly shows the correct channel with the Subscribed state."
}


Rules:

valid must be true ONLY when the subscription is visually convincing.

confidence must be an integer from 0 to 100.

reason must be short and factual.

Do not use markdown.
Do not use code blocks.
`;


    const response =
        await ai.models.generateContent({

            model: config.geminiModel,

            contents: [

                {

                    role: "user",

                    parts: [

                        {

                            inlineData: {

                                mimeType,

                                data: base64Image

                            }

                        },

                        {

                            text: prompt

                        }

                    ]

                }

            ],

            config: {

                temperature: 0,

                responseMimeType:
                    "application/json"

            }

        });


    let text =
        response.text;


    if (!text) {

        throw new Error(
            "Gemini returned an empty response."
        );

    }


    text =
        text
            .trim()
            .replace(
                /^```json/i,
                ""
            )
            .replace(
                /^```/i,
                ""
            )
            .replace(
                /```$/i,
                ""
            )
            .trim();


    let result;


    try {

        result =
            JSON.parse(text);

    } catch {

        throw new Error(
            `Invalid Gemini JSON response: ${text}`
        );

    }


    return {

        valid:
            Boolean(result.valid),

        confidence:
            Number(result.confidence) || 0,

        reason:
            String(
                result.reason ||
                "No reason provided."
            )

    };

}


// ============================================================
// LOGGING
// ============================================================

async function sendLog(
    guild,
    embed
) {

    if (!LOG_CHANNEL_ID) {
        return;
    }


    try {

        const channel =
            await guild.channels.fetch(
                LOG_CHANNEL_ID
            );


        if (!channel) {
            return;
        }


        await channel.send({
            embeds: [embed]
        });


    } catch (error) {

        console.error(
            "[LOG] Could not send log:",
            error.message
        );

    }

}


// ============================================================
// COOLDOWN
// ============================================================

function checkCooldown(
    userId
) {

    const db =
        loadDatabase();


    const lastAttempt =
        db.attempts[userId] || 0;


    const now =
        Date.now();


    const difference =
        now - lastAttempt;


    if (
        difference <
        config.cooldownMs
    ) {

        const remaining =
            Math.ceil(
                (
                    config.cooldownMs -
                    difference
                ) / 1000
            );


        return {

            allowed: false,

            remaining

        };

    }


    db.attempts[userId] =
        now;


    saveDatabase(db);


    return {

        allowed: true,

        remaining: 0

    };

}


// ============================================================
// CHECK VERIFIED
// ============================================================

function isAlreadyVerified(
    userId
) {

    const db =
        loadDatabase();


    return Boolean(
        db.verified[userId]
    );

}


// ============================================================
// MARK VERIFIED
// ============================================================

function markVerified(
    userId,
    data
) {

    const db =
        loadDatabase();


    db.verified[userId] = {

        ...data,

        verifiedAt:
            new Date().toISOString()

    };


    saveDatabase(db);

}


// ============================================================
// BOT READY
// ============================================================

client.once(
    "ready",
    () => {

        console.log("");

        console.log(
            "======================================"
        );

        console.log(
            "        YT VERIFIER ONLINE"
        );

        console.log(
            "======================================"
        );

        console.log(
            `Bot: ${client.user.tag}`
        );

        console.log(
            `Verify Channel: ${VERIFY_CHANNEL_ID}`
        );

        console.log(
            `Verify Role: ${VERIFY_ROLE_ID}`
        );

        console.log(
            `YouTube: ${YOUTUBE_CHANNEL_NAME}`
        );

        console.log(
            `Handle: ${YOUTUBE_HANDLE}`
        );

        console.log(
            `Gemini: ${config.geminiModel}`
        );

        console.log(
            "Mode: IMAGE ONLY"
        );

        console.log(
            "======================================"
        );

        console.log("");

    }
);


// ============================================================
// MESSAGE HANDLER
// ============================================================

client.on(
    "messageCreate",
    async message => {

        try {

            // ------------------------------------------------
            // Ignore bots
            // ------------------------------------------------

            if (
                message.author.bot
            ) {

                return;

            }


            // ------------------------------------------------
            // Only verification channel
            // ------------------------------------------------

            if (
                message.channel.id !==
                VERIFY_CHANNEL_ID
            ) {

                return;

            }


            // ------------------------------------------------
            // Guild only
            // ------------------------------------------------

            if (!message.guild) {

                return;

            }


            // =================================================
            // IMAGE ONLY CHANNEL
            // =================================================

            /*
             * Any normal text message gets deleted.
             *
             * Example:
             *
             * hello
             * how do I verify
             * test
             *
             * All are automatically deleted.
             */

            if (
                message.attachments.size === 0
            ) {

                try {

                    await message.delete();

                    console.log(
                        `[CLEANUP] Deleted text message from ${message.author.tag}`
                    );

                } catch (error) {

                    console.log(
                        "[CLEANUP] Could not delete text message:",
                        error.message
                    );

                }

                return;

            }


            // =================================================
            // FIND IMAGE
            // =================================================

            const image =
                message.attachments.find(
                    attachment =>
                        isImage(attachment)
                );


            // =================================================
            // DELETE NON-IMAGE ATTACHMENTS
            // =================================================

            if (!image) {

                try {

                    await message.delete();

                    console.log(
                        `[CLEANUP] Deleted non-image attachment from ${message.author.tag}`
                    );

                } catch (error) {

                    console.log(
                        "[CLEANUP] Could not delete attachment:",
                        error.message
                    );

                }

                return;

            }


            // =================================================
            // ALREADY VERIFIED
            // =================================================

            if (
                isAlreadyVerified(
                    message.author.id
                )
            ) {

                try {

                    await message.delete();

                } catch {}


                try {

                    await message.author.send({

                        embeds: [

                            new EmbedBuilder()

                                .setTitle(
                                    "✅ Already Verified"
                                )

                                .setDescription(
                                    `You are already verified in **${message.guild.name}**.`
                                )

                                .setFooter({

                                    text:
                                        "YouTube Verification System"

                                })

                        ]

                    });

                } catch {}


                return;

            }


            // =================================================
            // IMAGE SIZE
            // =================================================

            if (
                image.size >
                config.maxImageSize
            ) {

                try {

                    await message.delete();

                } catch {}


                return;

            }


            // =================================================
            // COOLDOWN
            // =================================================

            const cooldown =
                checkCooldown(
                    message.author.id
                );


            if (
                !cooldown.allowed
            ) {

                try {

                    await message.delete();

                } catch {}


                try {

                    await message.author.send({

                        embeds: [

                            new EmbedBuilder()

                                .setTitle(
                                    "⏳ Verification Cooldown"
                                )

                                .setDescription(

                                    `Please wait **${cooldown.remaining} seconds** before submitting another screenshot.`

                                )

                                .setFooter({

                                    text:
                                        "YouTube Verification System"

                                })

                        ]

                    });

                } catch {}


                return;

            }


            // =================================================
            // PROCESSING MESSAGE
            // =================================================

            const processing =
                await message.reply({

                    embeds: [

                        new EmbedBuilder()

                            .setTitle(
                                "🔍 Checking screenshot"
                            )

                            .setDescription(

                                "I'm checking your YouTube subscription screenshot..."

                            )

                            .setFooter({

                                text:
                                    "YT Verification System"

                            })

                    ],

                    allowedMentions: {

                        repliedUser: false

                    }

                });


            console.log(
                `[VERIFY] Checking ${message.author.tag} (${message.author.id})`
            );


            // =================================================
            // DOWNLOAD IMAGE
            // =================================================

            const imageBuffer =
                await downloadImage(
                    image.url
                );


            // =================================================
            // GEMINI CHECK
            // =================================================

            const result =
                await verifyScreenshot(

                    imageBuffer,

                    getMimeType(image)

                );


            console.log(
                `[VERIFY] ${message.author.tag}:`,
                result
            );


            // =================================================
            // SUCCESS
            // =================================================

            if (
                result.valid &&
                result.confidence >= 75
            ) {

                // ---------------------------------------------
                // GET ROLE
                // ---------------------------------------------

                const role =
                    await message.guild.roles.fetch(
                        VERIFY_ROLE_ID
                    );


                if (!role) {

                    await processing.edit({

                        embeds: [

                            new EmbedBuilder()

                                .setTitle(
                                    "❌ Configuration Error"
                                )

                                .setDescription(
                                    "The verification role could not be found."
                                )

                        ]

                    });

                    return;

                }


                // ---------------------------------------------
                // ROLE POSITION
                // ---------------------------------------------

                if (
                    role.managed ||
                    role.position >=
                    message.guild.members.me.roles.highest.position
                ) {

                    await processing.edit({

                        embeds: [

                            new EmbedBuilder()

                                .setTitle(
                                    "❌ Role Permission Error"
                                )

                                .setDescription(

                                    "I can't assign the verification role. Move my bot role above the verification role."

                                )

                        ]

                    });

                    return;

                }


                // ---------------------------------------------
                // GET MEMBER
                // ---------------------------------------------

                const member =
                    await message.guild.members.fetch(
                        message.author.id
                    );


                // ---------------------------------------------
                // ADD ROLE
                // ---------------------------------------------

                await member.roles.add(

                    role,

                    "YouTube subscription screenshot verified"

                );


                // ---------------------------------------------
                // SAVE VERIFICATION
                // ---------------------------------------------

                markVerified(

                    message.author.id,

                    {

                        username:
                            message.author.tag,

                        confidence:
                            result.confidence,

                        reason:
                            result.reason,

                        messageId:
                            message.id

                    }

                );


                // =================================================
                // SUCCESS DM
                // =================================================

                const successEmbed =

                    new EmbedBuilder()

                        .setTitle(
                            "✅ YouTube Verification Successful"
                        )

                        .setDescription(

                            `You are now verified in **${message.guild.name}**!\n\n` +

                            `The ${role} role has been added to your account.`

                        )

                        .addFields(

                            {

                                name:
                                    "📺 Channel",

                                value:
                                    YOUTUBE_CHANNEL_NAME,

                                inline: true

                            },

                            {

                                name:
                                    "🤖 Verification",

                                value:
                                    "Screenshot verified",

                                inline: true

                            }

                        )

                        .setFooter({

                            text:
                                "YouTube Verification System"

                        })

                        .setTimestamp();


                let dmSent =
                    false;


                try {

                    await message.author.send({

                        embeds: [
                            successEmbed
                        ]

                    });


                    dmSent =
                        true;


                    console.log(
                        `[DM] Sent verification DM to ${message.author.tag}`
                    );

                } catch (dmError) {

                    console.log(

                        `[DM] Could not DM ${message.author.tag}:`,

                        dmError.message

                    );

                }


                // =================================================
                // LOG APPROVAL
                // =================================================

                const logEmbed =

                    new EmbedBuilder()

                        .setTitle(
                            "✅ YouTube Verification Approved"
                        )

                        .addFields(

                            {

                                name:
                                    "User",

                                value:
                                    `${message.author} (${message.author.id})`

                            },

                            {

                                name:
                                    "Confidence",

                                value:
                                    `${result.confidence}%`,

                                inline: true

                            },

                            {

                                name:
                                    "DM",

                                value:
                                    dmSent
                                        ? "✅ Sent"
                                        : "❌ Failed",

                                inline: true

                            },

                            {

                                name:
                                    "Reason",

                                value:
                                    result.reason

                            }

                        )

                        .setTimestamp();


                await sendLog(

                    message.guild,

                    logEmbed

                );


                // =================================================
                // CLEAN EVERYTHING FROM VERIFY CHANNEL
                // =================================================

                if (
                    config.deleteScreenshotAfterVerification
                ) {

                    await sleep(1500);


                    // Delete user's screenshot
                    try {

                        await message.delete();

                        console.log(
                            "[CLEANUP] Deleted successful screenshot."
                        );

                    } catch (error) {

                        console.log(

                            "[CLEANUP] Could not delete screenshot:",

                            error.message

                        );

                    }


                    // Delete bot's processing message
                    try {

                        await processing.delete();

                        console.log(
                            "[CLEANUP] Deleted processing message."
                        );

                    } catch (error) {

                        console.log(

                            "[CLEANUP] Could not delete processing message:",

                            error.message

                        );

                    }

                }


                return;

            }


            // =================================================
            // FAILED VERIFICATION
            // =================================================

            const failEmbed =

                new EmbedBuilder()

                    .setTitle(
                        "❌ Verification Failed"
                    )

                    .setDescription(

                        "I couldn't confirm that this screenshot shows an active subscription to the required YouTube channel."

                    )

                    .addFields(

                        {

                            name:
                                "Reason",

                            value:
                                result.reason ||
                                "The screenshot was unclear."

                        },

                        {

                            name:
                                "Try Again",

                            value:

                                "Open the YouTube channel, make sure the button says **Subscribed**, then take a clear screenshot showing the channel name and subscription button."

                        }

                    )

                    .setFooter({

                        text:
                            "You can submit another screenshot after the cooldown."

                    });


            await processing.edit({

                embeds: [
                    failEmbed
                ]

            });


            // =================================================
            // FAILED LOG
            // =================================================

            const failLog =

                new EmbedBuilder()

                    .setTitle(
                        "❌ YouTube Verification Rejected"
                    )

                    .addFields(

                        {

                            name:
                                "User",

                            value:
                                `${message.author} (${message.author.id})`

                        },

                        {

                            name:
                                "Confidence",

                            value:
                                `${result.confidence}%`,

                            inline: true

                        },

                        {

                            name:
                                "Reason",

                            value:
                                result.reason

                        }

                    )

                    .setTimestamp();


            await sendLog(

                message.guild,

                failLog

            );


        } catch (error) {

            console.error(
                "Verification error:",
                error
            );


            // Try deleting the triggering message
            try {

                await message.delete();

            } catch {}


            // Try DMing the user instead of cluttering verify
            try {

                await message.author.send({

                    embeds: [

                        new EmbedBuilder()

                            .setTitle(
                                "⚠️ Verification Error"
                            )

                            .setDescription(

                                "Something went wrong while checking your screenshot. Please try again in a moment."

                            )

                            .setFooter({

                                text:
                                    "YouTube Verification System"

                            })

                    ]

                });

            } catch {}

        }

    }
);


// ============================================================
// LOGIN
// ============================================================

client.login(TOKEN);
